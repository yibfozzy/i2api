# ABSTRACT: i2api utility
package App::I2::API;
$App::I2::API::VERSION = '0.001';
use strict;
use warnings;
use App::Cmd::Setup -app;

1;
