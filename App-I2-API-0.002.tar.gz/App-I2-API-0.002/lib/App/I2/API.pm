# ABSTRACT: i2api utility
package App::I2::API;
$App::I2::API::VERSION = '0.002';
use strict;
use warnings;
use App::Cmd::Setup -app;

1;
